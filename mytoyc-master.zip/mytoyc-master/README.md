# mytoyc

Toy programming language for the compiler construction course. Original code is taken from the tutorial by L. Segal at http://gnuu.org/2009/09/18/writing-your-own-toy-compiler. Original code at github: https://github.com/lsegal/my_toy_compiler.